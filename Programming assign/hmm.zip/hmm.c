#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct l1{
    int val;
    char* word;
    struct l1* next;
    struct l1* prev;
};
struct l1*head=NULL;



void visit(char* str1){
    if (head==NULL){
        head=(struct l1*)malloc(sizeof(struct l1));
        head->word=str1;
        head->next=NULL;
        head->prev=NULL;
        printf("head\n");
        printf("%s \n",head->word);
    }
    
    else{
        struct l1* temp= head;
        printf("omk");
        printf("%s",head->word);
        while(temp->next!=NULL){
            temp=temp->next;
        }
        temp->next=(struct l1*)malloc(sizeof(struct l1));
        temp->next->word=str1;
        temp->next->next=NULL;
        temp->next->prev=temp;
        printf("%s",temp->next->prev->word);
    }
    printf("\n%s",head->word);
    
    return ;
}

int main(){
    while(1){
        char c;
        scanf("%c",&c);
        if(c=='E'){
            exit(0);
        }
        if(c=='V'){
            char str[100];
            scanf("%s",&str);
            visit(str);

    }
    }
}